package com.example.brind.appsec;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.*;
import android.graphics.Typeface;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.text.Html;
        import android.text.Spanned;
        import android.content.Intent;
        import android.content.pm.*;
        import android.widget.TextView;
        import java.util.*;

        import static com.example.brind.appsec.R.id.textView1;
        import static com.example.brind.appsec.R.id.textView2;


public class PermissionsActivity extends AppCompatActivity {
    TextView textview;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
        // Set the action bar color
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.RED));
        final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        final List pkgAppsList = getPackageManager().queryIntentActivities(mainIntent, 0);
        int count = 0;
        for (Object obj : pkgAppsList)
        {
            ResolveInfo resolveInfo = (ResolveInfo) obj;
            PackageInfo packageInfo = null;
            StringBuffer permissions = new StringBuffer();
            final TextView tw = (TextView) findViewById(textView1);
            try {
                packageInfo = getPackageManager().getPackageInfo(resolveInfo.activityInfo.packageName, PackageManager.GET_PERMISSIONS);
                count++;

            } catch (PackageManager.NameNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            String[] requestedPermissions = packageInfo.requestedPermissions;
            if (requestedPermissions != null)
            {
                for (int i = 0; i < requestedPermissions.length; i++)
                {
                    permissions.append(requestedPermissions[i] + "\n");
                }
                tw.append(packageInfo.packageName + "\n" + permissions);
            }
            tw.append("\n------------------------------------------------------------");
        }


    }
    public void onStartScanClick(View view)
    {
        Intent getScanResult = new Intent(this , SplashActivity.class);
        final int result=1;
        getScanResult.putExtra("callActivity","MainActivity");
        startActivity(getScanResult);
    }
}

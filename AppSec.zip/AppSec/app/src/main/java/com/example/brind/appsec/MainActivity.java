package com.example.brind.appsec;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity  {
    TextView textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview = (TextView) findViewById(R.id.TextView01);
        // Set the action bar color
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.RED));


    }

    public void onStartScanClick(View view)
    {
        Intent getScanResult = new Intent(this , SplashActivity.class);
        final int result=1;
        getScanResult.putExtra("callActivity","MainActivity");
        startActivity(getScanResult);
    }
}

package com.example.brind.appsec;

import android.app.Application;
import android.os.SystemClock;

import java.util.concurrent.TimeUnit;

public class Apps extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // Don't do this! This is just so cold launches take some time
        SystemClock.sleep(TimeUnit.SECONDS.toMillis(3));
    }
}
package com.example.brind.appsec;

/**
 * Created by brind on 2017-11-06.
 */

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {
    TextView textview;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another);
        // Set the action bar color
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.RED));

        Intent activityresult = getIntent();
        String prvresult= activityresult.getExtras().getString("callingActivity");

    }

    public void onShowResult(View view)
    {
        Intent getPermissionResult = new Intent(this , PermissionsActivity.class);
        final int result=1;
        getPermissionResult.putExtra("callActivity","MainActivity");
        startActivity(getPermissionResult);
    }

    public void onShowAppResult(View view)
    {
        Intent getDangerousResult = new Intent(this , DangerousActivity.class);
        final int result=1;
        getDangerousResult.putExtra("callActivity","MainActivity");
        startActivity(getDangerousResult);
    }
}
